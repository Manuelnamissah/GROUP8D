"""
Minimal SQLite-backed user store for real signup/login.

No ORM needed for a single `users` table — plain sqlite3 from the
standard library, one file on disk, safe for the concurrent-but-light
traffic this API expects. Swap this out for Postgres later by replacing
just this module if you outgrow it.
"""

from __future__ import annotations

import os
import re
import sqlite3
import threading
from pathlib import Path
from typing import Optional

DB_PATH = Path(os.environ.get("BCDD_DB_PATH", Path(__file__).resolve().parent.parent / "data" / "bcdd.db"))
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

_lock = threading.Lock()

USERNAME_RE = re.compile(r"^[a-zA-Z0-9_.-]{3,32}$")


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def init_db() -> None:
    with _lock, _connect() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                email TEXT,
                password_hash TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT (datetime('now'))
            );
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                prediction TEXT NOT NULL,
                confidence REAL NOT NULL,
                demo_mode INTEGER NOT NULL,
                created_at TEXT NOT NULL DEFAULT (datetime('now'))
            );
            """
        )


def create_user(username: str, password_hash: str, email: Optional[str] = None) -> sqlite3.Row:
    with _lock, _connect() as conn:
        cur = conn.execute(
            "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)",
            (username, email, password_hash),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM users WHERE id = ?", (cur.lastrowid,)).fetchone()
        return row


def get_user_by_username(username: str) -> Optional[sqlite3.Row]:
    with _connect() as conn:
        return conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()


def get_user_by_id(user_id: int) -> Optional[sqlite3.Row]:
    with _connect() as conn:
        return conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()


def record_scan(user_id: int, prediction: str, confidence: float, demo_mode: bool) -> None:
    with _lock, _connect() as conn:
        conn.execute(
            "INSERT INTO scans (user_id, prediction, confidence, demo_mode) VALUES (?, ?, ?, ?)",
            (user_id, prediction, confidence, int(demo_mode)),
        )
        conn.commit()


def get_scan_history(user_id: int, limit: int = 20):
    with _connect() as conn:
        return conn.execute(
            "SELECT prediction, confidence, demo_mode, created_at FROM scans "
            "WHERE user_id = ? ORDER BY id DESC LIMIT ?",
            (user_id, limit),
        ).fetchall()
