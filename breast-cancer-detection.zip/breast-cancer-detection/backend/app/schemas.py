import re
from typing import Dict, List, Optional

from pydantic import BaseModel, Field, field_validator

from app.db import USERNAME_RE

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class SignupRequest(BaseModel):
    username: str = Field(..., min_length=3, max_length=32)
    password: str = Field(..., min_length=8, max_length=128)
    email: Optional[str] = None

    @field_validator("username")
    @classmethod
    def validate_username(cls, v: str) -> str:
        if not USERNAME_RE.match(v):
            raise ValueError(
                "Username must be 3-32 characters: letters, numbers, dots, "
                "underscores or hyphens only."
            )
        return v

    @field_validator("email")
    @classmethod
    def validate_email(cls, v: Optional[str]) -> Optional[str]:
        if v and not _EMAIL_RE.match(v):
            raise ValueError("Invalid email address.")
        return v


class LoginRequest(BaseModel):
    username: str
    password: str


class UserOut(BaseModel):
    id: int
    username: str
    email: Optional[str] = None


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


class ScanHistoryItem(BaseModel):
    prediction: str
    confidence: float
    demo_mode: bool
    created_at: str


class PredictionResponse(BaseModel):
    prediction: str = Field(..., description="Top predicted class label.")
    confidence: float = Field(..., description="Confidence of the top class, 0-1.")
    probabilities: Dict[str, float] = Field(
        ..., description="Probability for every class, 0-1."
    )
    inference_time_ms: float = Field(..., description="Server-side inference time.")
    demo_mode: bool = Field(
        ...,
        description=(
            "True if no trained weights were found and the API is returning "
            "randomized placeholder predictions for demonstration purposes."
        ),
    )

    class Config:
        json_schema_extra = {
            "example": {
                "prediction": "malignant",
                "confidence": 0.82,
                "probabilities": {"benign": 0.11, "malignant": 0.82, "invalid": 0.07},
                "inference_time_ms": 42.3,
                "demo_mode": False,
            }
        }


class HealthResponse(BaseModel):
    status: str
    model_loaded: bool
    demo_mode: bool
    classes: List[str]
