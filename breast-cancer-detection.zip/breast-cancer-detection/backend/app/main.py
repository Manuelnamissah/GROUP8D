"""
Breast Cancer Detection API
============================
FastAPI backend that serves the MobileNetV2-based breast cancer detection
model described in the project documentation (BCDD system).

Endpoints
---------
GET  /health          -> service + model status check
POST /predict          -> classify a single histopathology image
                           (multipart/form-data, field name: "file")

Run locally:
    uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload

Run in production (on the VPS), see README.md for the systemd + nginx setup.
"""

import io
import logging
import time
from typing import Dict, List

import numpy as np
from fastapi import Depends, FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image, UnidentifiedImageError

from app.auth import create_access_token, get_current_user, hash_password, verify_password
from app.db import (
    create_user,
    get_scan_history,
    get_user_by_username,
    init_db,
    record_scan,
)
from app.model import CLASS_NAMES, ModelNotLoadedError, get_predictor
from app.schemas import (
    HealthResponse,
    LoginRequest,
    PredictionResponse,
    ScanHistoryItem,
    SignupRequest,
    TokenResponse,
    UserOut,
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("bcdd")

app = FastAPI(
    title="Breast Cancer Detection API",
    description=(
        "Classifies breast histopathology images (40x magnification) as "
        "benign, malignant, or invalid using a MobileNetV2 transfer-learning "
        "model. Educational / assistive tool only — not a substitute for "
        "clinical diagnosis."
    ),
    version="1.0.0",
)

# Allow the Flutter app / web frontend to call this API from any origin.
# Tighten allow_origins to your app's domain(s) once you go to production.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

MAX_UPLOAD_BYTES = 10 * 1024 * 1024  # 10 MB
ALLOWED_CONTENT_TYPES = {"image/jpeg", "image/png", "image/jpg", "image/webp"}


@app.on_event("startup")
async def load_model_on_startup() -> None:
    """Load the trained model once, at process start, instead of per-request."""
    init_db()
    try:
        predictor = get_predictor()
        logger.info(
            "Model loaded successfully (demo_mode=%s).", predictor.demo_mode
        )
    except Exception:  # noqa: BLE001 — we want the server to still boot
        logger.exception(
            "Model failed to load. /predict will return 503 until this is fixed."
        )


# ---------------------------------------------------------------------------
# Authentication — real accounts, hashed passwords, signed JWTs
# ---------------------------------------------------------------------------
@app.post("/auth/signup", response_model=TokenResponse, tags=["auth"])
async def signup(body: SignupRequest) -> TokenResponse:
    if get_user_by_username(body.username) is not None:
        raise HTTPException(status_code=409, detail="That username is already taken.")

    user = create_user(body.username, hash_password(body.password), body.email)
    token = create_access_token(user["id"], user["username"])
    logger.info("New account created: %s", user["username"])
    return TokenResponse(
        access_token=token,
        user=UserOut(id=user["id"], username=user["username"], email=user["email"]),
    )


@app.post("/auth/login", response_model=TokenResponse, tags=["auth"])
async def login(body: LoginRequest) -> TokenResponse:
    user = get_user_by_username(body.username)
    if user is None or not verify_password(body.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Incorrect username or password.")

    token = create_access_token(user["id"], user["username"])
    return TokenResponse(
        access_token=token,
        user=UserOut(id=user["id"], username=user["username"], email=user["email"]),
    )


@app.get("/auth/me", response_model=UserOut, tags=["auth"])
async def me(current_user=Depends(get_current_user)) -> UserOut:
    return UserOut(id=current_user["id"], username=current_user["username"], email=current_user["email"])


@app.get("/scans/history", response_model=List[ScanHistoryItem], tags=["scans"])
async def scan_history(current_user=Depends(get_current_user)) -> List[ScanHistoryItem]:
    rows = get_scan_history(current_user["id"])
    return [
        ScanHistoryItem(
            prediction=row["prediction"],
            confidence=row["confidence"],
            demo_mode=bool(row["demo_mode"]),
            created_at=row["created_at"],
        )
        for row in rows
    ]


@app.get("/", include_in_schema=False)
async def root() -> Dict[str, str]:
    return {"message": "Breast Cancer Detection API — see /docs for usage."}


@app.get("/health", response_model=HealthResponse)
async def health() -> HealthResponse:
    try:
        predictor = get_predictor()
        return HealthResponse(
            status="ok",
            model_loaded=True,
            demo_mode=predictor.demo_mode,
            classes=CLASS_NAMES,
        )
    except ModelNotLoadedError:
        return HealthResponse(
            status="degraded",
            model_loaded=False,
            demo_mode=False,
            classes=CLASS_NAMES,
        )


@app.post("/predict", response_model=PredictionResponse)
async def predict(
    file: UploadFile = File(...),
    current_user=Depends(get_current_user),
) -> PredictionResponse:
    """
    Classify a single uploaded histopathology image.

    Requires a valid Bearer token from /auth/login or /auth/signup — this
    is a real, enforced auth check, not a UI-only gate: requests without
    a valid token get a 401 before any image processing happens.

    Mirrors the API contract described in the project documentation:
        {"prediction": "malignant", "confidence": 0.82}
    (this implementation additionally returns the full per-class
    probability breakdown, which the mobile app / frontend can ignore
    if it only needs the top prediction).
    """
    if file.content_type not in ALLOWED_CONTENT_TYPES:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported file type '{file.content_type}'. "
            f"Upload a JPEG, PNG or WEBP image.",
        )

    raw_bytes = await file.read()
    if len(raw_bytes) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="Image exceeds 10 MB limit.")

    try:
        image = Image.open(io.BytesIO(raw_bytes)).convert("RGB")
    except UnidentifiedImageError as exc:
        raise HTTPException(
            status_code=400, detail="File could not be read as an image."
        ) from exc

    try:
        predictor = get_predictor()
    except ModelNotLoadedError as exc:
        raise HTTPException(
            status_code=503,
            detail="Model is not available on the server right now.",
        ) from exc

    start = time.perf_counter()
    label, confidence, probabilities = predictor.predict(image)
    elapsed_ms = (time.perf_counter() - start) * 1000

    logger.info(
        "Prediction: %s (%.2f%%) in %.1fms — user=%s file=%s size=%d bytes",
        label,
        confidence * 100,
        elapsed_ms,
        current_user["username"],
        file.filename,
        len(raw_bytes),
    )
    record_scan(current_user["id"], label, confidence, predictor.demo_mode)

    return PredictionResponse(
        prediction=label,
        confidence=round(confidence, 4),
        probabilities={k: round(v, 4) for k, v in probabilities.items()},
        inference_time_ms=round(elapsed_ms, 1),
        demo_mode=predictor.demo_mode,
    )
