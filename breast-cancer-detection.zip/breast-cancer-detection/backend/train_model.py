"""
train_model.py
===============
Trains the MobileNetV2 transfer-learning classifier described in the
project documentation (Chapter 3, sections 3.5-3.7) and saves it to
model/breast_cancer_mobilenetv2.keras, where app/model.py will
automatically pick it up.

Expected data layout (three-class BreakHis split, 40x magnification):

    data/
      train/
        benign/     *.png
        malignant/  *.png
        invalid/    *.png
      val/
        benign/ ...
        malignant/ ...
        invalid/ ...
      test/
        benign/ ...
        malignant/ ...
        invalid/ ...

Usage:
    python train_model.py --data-dir ./data --epochs 20 --batch-size 32

Notes on reproducing the documented results:
    - Images are resized to 224x224 and rescaled to [0,1] (Chapter 3.5).
    - Augmentation: rotation, horizontal/vertical flip, zoom (Chapter 3.5).
    - Optimizer: Adam, loss: categorical cross-entropy (Chapter 3.6.3).
    - The documentation reports ~92% train / ~93-94% val accuracy over
      20 epochs and 94% test accuracy on 3,085 held-out samples — actual
      numbers will depend on your exact train/val/test split of BreakHis.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import tensorflow as tf
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
from tensorflow.keras.preprocessing.image import ImageDataGenerator

from app.model import CLASS_NAMES, IMAGE_SIZE, build_model


def make_generators(data_dir: Path, batch_size: int):
    train_datagen = ImageDataGenerator(
        rescale=1.0 / 255,
        rotation_range=30,
        horizontal_flip=True,
        vertical_flip=True,
        zoom_range=0.2,
        width_shift_range=0.1,
        height_shift_range=0.1,
    )
    eval_datagen = ImageDataGenerator(rescale=1.0 / 255)

    train_gen = train_datagen.flow_from_directory(
        data_dir / "train",
        target_size=IMAGE_SIZE,
        batch_size=batch_size,
        classes=CLASS_NAMES,
        class_mode="categorical",
        shuffle=True,
    )
    val_gen = eval_datagen.flow_from_directory(
        data_dir / "val",
        target_size=IMAGE_SIZE,
        batch_size=batch_size,
        classes=CLASS_NAMES,
        class_mode="categorical",
        shuffle=False,
    )
    test_gen = eval_datagen.flow_from_directory(
        data_dir / "test",
        target_size=IMAGE_SIZE,
        batch_size=batch_size,
        classes=CLASS_NAMES,
        class_mode="categorical",
        shuffle=False,
    )
    return train_gen, val_gen, test_gen


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=Path("data"))
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--dropout", type=float, default=0.3)
    parser.add_argument(
        "--fine-tune",
        action="store_true",
        help="Unfreeze the MobileNetV2 base for a fine-tuning phase after "
        "the initial head-only training.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("model/breast_cancer_mobilenetv2.keras"),
    )
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    train_gen, val_gen, test_gen = make_generators(args.data_dir, args.batch_size)

    model = build_model(dropout_rate=args.dropout, fine_tune=False)
    model.summary()

    callbacks = [
        EarlyStopping(monitor="val_loss", patience=5, restore_best_weights=True),
        ModelCheckpoint(str(args.output), monitor="val_accuracy", save_best_only=True),
        ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=3, min_lr=1e-6),
    ]

    history = model.fit(
        train_gen,
        validation_data=val_gen,
        epochs=args.epochs,
        callbacks=callbacks,
    )

    if args.fine_tune:
        print("\nFine-tuning: unfreezing MobileNetV2 base at a low LR...")
        base_model = model.get_layer("mobilenetv2_1.00_224")
        base_model.trainable = True
        model.compile(
            optimizer=tf.keras.optimizers.Adam(learning_rate=1e-5),
            loss="categorical_crossentropy",
            metrics=["accuracy"],
        )
        model.fit(
            train_gen,
            validation_data=val_gen,
            epochs=max(5, args.epochs // 4),
            callbacks=callbacks,
        )

    model.save(args.output)
    print(f"\nSaved trained model to {args.output}")

    print("\nEvaluating on the held-out test set...")
    results = model.evaluate(test_gen, return_dict=True)
    print(json.dumps(results, indent=2))

    # Full classification report + confusion matrix (mirrors Chapter 4)
    from sklearn.metrics import classification_report, confusion_matrix
    import numpy as np

    test_gen.reset()
    y_true = test_gen.classes
    y_pred_probs = model.predict(test_gen)
    y_pred = np.argmax(y_pred_probs, axis=1)

    print("\nClassification report:")
    print(classification_report(y_true, y_pred, target_names=CLASS_NAMES))
    print("Confusion matrix:")
    print(confusion_matrix(y_true, y_pred))


if __name__ == "__main__":
    main()
