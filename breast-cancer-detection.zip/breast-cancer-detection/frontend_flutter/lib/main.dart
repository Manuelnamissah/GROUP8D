import 'package:flutter/material.dart';
import 'screens/login_screen.dart';

void main() => runApp(const BcddApp());

/// Brand palette shared across the app — deliberately not the generic
/// pink-ribbon pink; a deep berry evokes the H&E histopathology stains
/// the app classifies, paired with a clinical teal accent.
class BcddColors {
  static const brand = Color(0xFF7A2048);
  static const brandDark = Color(0xFF5C1737);
  static const teal = Color(0xFF1F6E6E);
  static const benign = Color(0xFF3F7A5C);
  static const malignant = Color(0xFFB23A48);
  static const invalid = Color(0xFFB4791E);
  static const paper = Color(0xFFFBF7F5);
  static const ink = Color(0xFF241A20);
}

class BcddApp extends StatelessWidget {
  const BcddApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Breast Cancer Detection',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: BcddColors.paper,
        colorScheme: ColorScheme.fromSeed(
          seedColor: BcddColors.brand,
          primary: BcddColors.brand,
        ),
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: BcddColors.brand,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: BcddColors.brand,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        ),
      ),
      home: const LoginScreen(),
    );
  }
}
