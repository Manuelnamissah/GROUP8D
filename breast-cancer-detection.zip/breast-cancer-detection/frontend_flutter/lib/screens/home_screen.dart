import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import '../main.dart';
import '../models/prediction.dart';
import '../services/api_service.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  File? _selectedImage;
  Prediction? _result;
  bool _loading = false;
  String? _error;
  final List<ScanRecord> _history = [];

  Future<void> _pickImage(ImageSource source) async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: source, imageQuality: 90);
    if (picked == null) return;
    setState(() {
      _selectedImage = File(picked.path);
      _result = null;
      _error = null;
    });
  }

  Future<void> _analyze() async {
    if (_selectedImage == null) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final prediction = await ApiService.predict(_selectedImage!);
      setState(() {
        _result = prediction;
        _history.insert(
          0,
          ScanRecord(imagePath: _selectedImage!.path, prediction: prediction, timestamp: DateTime.now()),
        );
      });
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } finally {
      setState(() => _loading = false);
    }
  }

  void _clear() {
    setState(() {
      _selectedImage = null;
      _result = null;
      _error = null;
    });
  }

  Color _colorFor(String label) {
    switch (label) {
      case 'benign':
        return BcddColors.benign;
      case 'malignant':
        return BcddColors.malignant;
      default:
        return BcddColors.invalid;
    }
  }

  IconData _iconFor(String label) {
    switch (label) {
      case 'benign':
        return Icons.verified_outlined;
      case 'malignant':
        return Icons.warning_amber_rounded;
      default:
        return Icons.error_outline;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Breast Cancer Detection'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const SettingsScreen())),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Upload a histopathology image for AI-based analysis',
              style: TextStyle(color: Colors.black54)),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.image_outlined),
                  label: const Text('Select image'),
                  onPressed: () => _pickImage(ImageSource.gallery),
                ),
              ),
              const SizedBox(width: 8),
              OutlinedButton(
                onPressed: () => _pickImage(ImageSource.camera),
                child: const Icon(Icons.photo_camera_outlined),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _buildPreview(),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  icon: _loading
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                        )
                      : const Icon(Icons.biotech_outlined),
                  label: Text(_loading ? 'Analyzing…' : 'Analyze image'),
                  onPressed: _selectedImage == null || _loading ? null : _analyze,
                ),
              ),
              const SizedBox(width: 8),
              OutlinedButton.icon(
                icon: const Icon(Icons.close),
                label: const Text('Clear'),
                onPressed: _clear,
              ),
            ],
          ),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(_error!, style: const TextStyle(color: BcddColors.malignant)),
          ],
          if (_result != null) ...[
            const SizedBox(height: 16),
            _buildResultCard(_result!),
          ],
          const SizedBox(height: 24),
          const Text('Scan history', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          if (_history.isEmpty)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(.03),
                borderRadius: BorderRadius.circular(12),
              ),
              alignment: Alignment.center,
              child: const Text('No scans yet. Your results will appear here.',
                  style: TextStyle(color: Colors.black54)),
            )
          else
            ..._history.map(_historyTile),
        ],
      ),
    );
  }

  Widget _buildPreview() {
    if (_selectedImage == null) {
      return Container(
        height: 180,
        decoration: BoxDecoration(
          border: Border.all(color: Colors.black12),
          borderRadius: BorderRadius.circular(14),
          color: Colors.black.withOpacity(.02),
        ),
        alignment: Alignment.center,
        child: const Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.image_outlined, size: 34, color: Colors.black26),
            SizedBox(height: 6),
            Text('No image selected yet', style: TextStyle(color: Colors.black45)),
          ],
        ),
      );
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: Image.file(_selectedImage!, height: 200, width: double.infinity, fit: BoxFit.cover),
    );
  }

  Widget _buildResultCard(Prediction result) {
    final color = _colorFor(result.label);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(.08),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(backgroundColor: color, child: Icon(_iconFor(result.label), color: Colors.white, size: 18)),
              const SizedBox(width: 10),
              Text('${result.label[0].toUpperCase()}${result.label.substring(1)} result',
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            ],
          ),
          const SizedBox(height: 12),
          Text('Confidence score', style: TextStyle(fontSize: 12, color: Colors.black.withOpacity(.6))),
          const SizedBox(height: 4),
          ClipRRect(
            borderRadius: BorderRadius.circular(99),
            child: LinearProgressIndicator(
              value: result.confidence,
              minHeight: 7,
              backgroundColor: Colors.black.withOpacity(.08),
              valueColor: AlwaysStoppedAnimation(color),
            ),
          ),
          const SizedBox(height: 4),
          Text('${(result.confidence * 100).toStringAsFixed(0)}%',
              style: const TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 10),
          if (result.demoMode)
            const Text('Demo mode — this is a placeholder, not a trained prediction.',
                style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic, color: Colors.black54)),
        ],
      ),
    );
  }

  Widget _historyTile(ScanRecord record) {
    final color = _colorFor(record.prediction.label);
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: Colors.black.withOpacity(.06)),
      ),
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Image.file(File(record.imagePath), width: 44, height: 44, fit: BoxFit.cover),
        ),
        title: Row(
          children: [
            CircleAvatar(radius: 4, backgroundColor: color),
            const SizedBox(width: 6),
            Text('${record.prediction.label[0].toUpperCase()}${record.prediction.label.substring(1)}'),
          ],
        ),
        subtitle: Text(
          '${DateFormat('MMM d, y · h:mm a').format(record.timestamp)}'
          '${record.prediction.label == 'invalid' ? '' : ' · Confidence: ${(record.prediction.confidence * 100).toStringAsFixed(0)}%'}',
        ),
        trailing: const Icon(Icons.chevron_right),
      ),
    );
  }
}
