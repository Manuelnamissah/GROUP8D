# Breast Cancer Detection System (BCDD)

Implementation of the system described in "Breast Cancer Detection Using
Deep Learning-Based MobileNetV2" — a CNN backend served over a REST API,
with two ready-to-use frontends.

```
breast-cancer-detection/
├── backend/                 FastAPI + MobileNetV2 (the API, Chapter 3.3/3.8)
│   ├── app/
│   │   ├── main.py          POST /predict, GET /health
│   │   ├── model.py         MobileNetV2 architecture + inference wrapper
│   │   └── schemas.py       Request/response models
│   ├── train_model.py       Trains the model on your BreakHis folders
│   ├── requirements.txt
│   ├── Dockerfile
│   └── README.md            Local run + VPS deployment (systemd/Nginx/Docker)
│
├── web_demo/
│   └── index.html           Standalone web interface (upload → analyze → result → history)
│
└── frontend_flutter/         Flutter mobile app (Chapter 3.9)
    ├── lib/
    │   ├── main.dart
    │   ├── screens/          login, home (upload/analyze/history), settings
    │   ├── services/         api_service.dart
    │   └── models/
    ├── pubspec.yaml
    └── README.md
```

## Quickest path to a working demo

1. **Backend**
   ```bash
   cd backend
   python -m venv venv && source venv/bin/activate
   pip install -r requirements.txt
   uvicorn app.main:app --reload --port 8000
   ```
   It starts immediately in **demo mode** (clearly labeled in every API
   response) so you can wire up the frontend before you've trained the
   real model. Train the real classifier with `train_model.py` once you
   have the BreakHis dataset prepared (see `backend/README.md`).

2. **Web frontend** — just open `web_demo/index.html` in a browser (or
   serve it with any static file server). Tap the gear icon and set the
   API URL to `http://localhost:8000`, then create an account from the
   sign-up tab. There's no offline/demo predictor anymore — every
   analysis and every login is a real call to the backend.

3. **Flutter app** (optional, matches the documented mobile frontend)
   ```bash
   cd frontend_flutter
   flutter pub get
   flutter run
   ```

## Going to production

**The backend needs to be actually running somewhere reachable over the
internet** — that's what makes login and analysis "real" instead of
erroring out. The web frontend is just a static HTML file that calls
whatever API URL you put in its settings drawer; nothing in this repo
runs a server for you automatically.

Free, no-credit-card option (Render):
1. Push this project to a GitHub repo (Render deploys from Git, not a
   zip upload).
2. On [render.com](https://render.com), **New + → Blueprint**, connect
   that repo. Render reads `render.yaml` at the repo root and builds
   `backend/Dockerfile` for you, generating a random `SECRET_KEY`.
3. Once it's deployed you'll get a URL like
   `https://bcdd-backend-xxxx.onrender.com`.
4. Open `web_demo/index.html` (or `bcdd_web_frontend.html`) in a
   browser, tap the gear icon, paste that URL as the API base, save,
   then sign up.

Notes on the free tier: the service spins down after inactivity (the
first request after a while can take 30-60s to wake it up), and free
Render services don't get a persistent disk, so the SQLite user
database is wiped on every redeploy/restart. That's fine for trying it
out; move to a paid instance + disk (or swap `backend/app/db.py` for a
managed Postgres) once accounts need to actually persist.

Alternatively, deploy `backend/` on your own VPS behind Nginx (full
steps in `backend/README.md`, mirroring Chapter 3.8 of the
documentation) — that gives you a persistent disk by default. Either
way, train a real model with `train_model.py` on your prepared BreakHis
split once you're ready to move past the statistical placeholder.

## What's real vs. what you still need to supply

| Piece | Status |
|---|---|
| API contract, preprocessing, model architecture | Implemented, matches Chapter 3.5/3.6 |
| Backend deployment (systemd/Nginx/Docker) | Implemented |
| Training script (augmentation, callbacks, eval report) | Implemented |
| **Trained weights file** (`model/*.keras`) | **Not included** — train it yourself on BreakHis, or the API safely runs in demo mode until you do |
| Web frontend (login/sign-up, upload/analyze/history) | Implemented, calls the real `/auth/*` and `/predict` endpoints — no offline/demo fallback |
| User accounts / auth backend (`/auth/signup`, `/auth/login`, `/auth/me`, JWTs, hashed passwords in SQLite) | Implemented and enforced — `/predict` returns 401 without a valid token |
| Flutter mobile frontend | Upload/analyze/history/settings implemented; its login screen is still a local-only placeholder (see `frontend_flutter/lib/screens/login_screen.dart`) and needs to be wired to `/auth/login` and `/auth/signup` the same way the web frontend now is |

## Safety note
This system is an educational/assistive tool, not a diagnostic device —
every interface in this project reflects that, and predictions should
always be reviewed by a qualified medical professional (see Chapter
3.12 of the documentation).
